# CharpLox

A interpreter written in C# for the Lox programming language from the [Crafting Interpreters](https://craftinginterpreters.com) book.
